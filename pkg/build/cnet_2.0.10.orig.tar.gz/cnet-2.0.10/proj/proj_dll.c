#include "proj.h"

/*  This file implements a stop-and-wait Data Link Layer protocol for a
    node with multiple links.  The protocol is robust in the presence of
    frame loss and corruption on any link.  The protocol minimizes the
    unnecessary retransmission of frames by employing an adaptive timeout
    scheme to maintain a smoothed average of each link's bandwidth-independent
    round-trip time  (i.e. the randomness due to each link's
    propagation-delay is averaged over time).
    Any particular link is considered 'busy' if it has transmitted a data
    frame, but has not yet received an acknowledgment for it.  A link will
    not accept new data for transmission while the link is busy.
*/

typedef enum    { DLL_DATA, DLL_ACK }   DLL_FRAMEKIND;

typedef struct {
    DLL_FRAMEKIND   kind;      	/* only ever DLL_DATA or DLL_ACK */
    int             checksum;  	/* checksum of the whole frame */
    int             seq;       	/* using stopandwait - only ever 0 or 1 */
    CnetInt64	    timesent;	/* used for adaptive timeout calculation */
    int             len;       	/* the length of the packet field only */
    char	    packet[MAX_NL_PACKET_SIZE];
} DLL_FRAME;

#define DLL_FRAME_HEADER_SIZE	(sizeof(DLL_FRAME) - MAX_NL_PACKET_SIZE)
#define DLL_ACK_SIZE		DLL_FRAME_HEADER_SIZE
#define DLL_FRAME_SIZE(f)	(DLL_FRAME_HEADER_SIZE + f.len)

#define	DLL_ALPHA	0.8

typedef struct {
    int       	ackexpected;
    int		nextframetosend;
    int		frameexpected;

    int		busy;
    CnetInt64	srtt;

    char       	lastpacket[MAX_NL_PACKET_SIZE];
    int       	lastlength;
    CnetTimer	lasttimer;
} DLL_STATE;

static	DLL_STATE	*links;


/* ----------------------------------------------------------------------- */

/*  bandwidth_time() calculates the time required to fully transmit a frame
    of an indicated length (i.e. the time to 'put the data on the wire').
 */

static CnetInt64 bandwidth_time(int link, int frame_length)
{
    CnetInt64	total;

    int64_F2L(total, 8000000.0*(frame_length) / linkinfo[link].bandwidth);
    return(total);
}

/*  transmit_frame() builds a data frame for tranmission on the
    indicated link.  In all cases, the frame will carry its own frame-kind,
    sequence number, its payload length, and the time that its corresponding
    DLL_DATA payload was transmitted.  DLL_DATA frames require retransmission
    if their acknowledgment does not return to the original sender,
    and so transmit_frame() starts a new timer, set to expire just as the
    corresponding DLL_ACK is expected to return.  Both DLL_ACK and DLL_DATA
    frames carry their own checksum, to be validated by the frame's receiver.
 */

static void transmit_frame(int link, char *packet, DLL_FRAMEKIND kind,
			   int len,  int seqno, CnetInt64 timesent)
{
    DLL_FRAME	f;

    f.kind      = kind;
    f.seq       = seqno;
    f.timesent	= timesent;
    f.len       = len;

    if(kind == DLL_DATA) {
	CnetInt64	timeout;

        memcpy(f.packet, packet, len);
	timeout		= bandwidth_time(link, DLL_FRAME_SIZE(f));
	int64_ADD(timeout, timeout, links[link].srtt);
        links[link].lasttimer =
			CNET_start_timer(EV_TIMER1, timeout, (CnetData)link);
    }
    len		= DLL_FRAME_SIZE(f);
    f.checksum  = 0;
    f.checksum  = checksum_ccitt((unsigned char *)&f, len);
    CHECK(CNET_write_physical(link, (char *)&f, &len));
}


/*  The predicate function down_to_datalink() is called by the Network
    Layer (above) in an attempt to 'push' down a data packet for delivery.
    A link will not accept new data for transmission while the link is busy.
    Once the Data Link Layer accepts a data packet for delivery (from above),
    the Data Link Layer is considered the owner of that data until it has been
    successfully delivered (and acknowledged) by its neighbouring node.
    down_to_datalink() returns a Boolean indication as to whether it
    accepted the new packet for delivery.
 */

int down_to_datalink(int link, char *packet, int length)
{
    if(links[link].busy)
	return(FALSE);

    links[link].busy		= TRUE;
    links[link].lastlength	= length;
    memcpy(links[link].lastpacket, packet, length);

    transmit_frame(link, links[link].lastpacket, DLL_DATA,
		   links[link].lastlength, links[link].nextframetosend,
		   nodeinfo.time_in_usec);
    links[link].nextframetosend = 1-links[link].nextframetosend;

    return(TRUE);
}


/*  The event handler up_to_datalink() is invoked when a new frame
    arrives from the Physical Layer (the Physical Layer 'pushes' the new
    frame up to the Data Link Layer).
    The frame is first ignored if it appears to have been corrupted in transit.

 */

static void up_to_datalink(CnetEvent ev, CnetTimer timer, CnetData data)
{
    DLL_FRAME	f;
    int         link, len, checksum;

/*  READ THE FRAME 'up' FROM THE PHYSICAL LAYER */
    len         = sizeof(DLL_FRAME);
    CHECK(CNET_read_physical(&link, (char *)&f, &len));

/*  IGNORE THIS FRAME IF IT APPEARS TO HAVE BEEN CORRUPTED IN TRANSIT */
    checksum    = f.checksum;
    f.checksum  = 0;
    if(checksum_ccitt((unsigned char *)&f, len) != checksum)
        return;

/*  IF THIS FRAME IS THE ACKNOWLEDGMENT THAT WE EXPECT .... */
    if(f.kind == DLL_ACK) {
        if(f.seq == links[link].ackexpected) {

	    CnetInt64	bwtime, Pobserved;
	    float	Pold, Pnew;

/*  STOP THE TIMER TO PREVENT RETRANSMISSION OF THE ORIGINAL DATA */
            CNET_stop_timer(links[link].lasttimer);
	    links[link].lastlength	= 0;
            links[link].ackexpected	= 1-links[link].ackexpected;

/*  CALCULATE THE OBSERVED PROPAGATION DELAY TAKEN BY THIS FRAME TO RETURN */
	    int64_SUB(Pobserved, nodeinfo.time_in_usec, f.timesent);
	    bwtime	= bandwidth_time(link, DLL_FRAME_SIZE(f));
	    int64_SUB(Pobserved, Pobserved, bwtime);

/*  MAINTAIN A SMOOTHED AVERAGE OF OBSERVED ROUND-TRIP TIMES */
	    int64_L2F(Pold, links[link].srtt);
	    int64_L2F(Pnew, Pobserved);
	    int64_F2L(links[link].srtt, DLL_ALPHA*Pold + (1.0-DLL_ALPHA)*Pnew);

/*  HAVING NOW SUCCESSFULLY DELIVERED THIS FRAME,
    ATTEMPT TO 'PULL-DOWN' THE NEXT PACKET FROM THE NETWORK LAYER ABOVE */
	    if(down_from_network(link, links[link].lastpacket,
				      &links[link].lastlength)) {
		transmit_frame(link,  links[link].lastpacket, DLL_DATA,
		       links[link].lastlength, links[link].nextframetosend,
		       nodeinfo.time_in_usec);
		links[link].nextframetosend = 1-links[link].nextframetosend;
	    }
	    else
		links[link].busy	= FALSE;
        }
    }
/*  IF THIS FRAME A NEW DATA, PUSH ITS PAYLOAD TO THE NETWORK LAYER */
    else if(f.kind == DLL_DATA) {
        if(f.seq == links[link].frameexpected) {

	    up_to_network(link, f.packet, f.len);
            links[link].frameexpected = 1-links[link].frameexpected;
        }
/*  AND IN ALL CASES, RETURN AN ACKNOWLEDGMENT FRAME */
        transmit_frame(link, (char *)NULL, DLL_ACK, 0, f.seq, f.timesent);
    }
}


/*  The event-handler dll_timeouts() will be invoked if a DLL_DATA
    frame's corresponding DLL_ACK frame does not return in the time expected.
    We determine the link to which the timeout refers, and retransmit the
    original packet.
 */

static void dll_timeouts(CnetEvent ev, CnetTimer timer, CnetData data)
{
    int	link	= (int)data;

    transmit_frame(link, links[link].lastpacket, DLL_DATA,
		   links[link].lastlength, links[link].ackexpected,
		   nodeinfo.time_in_usec);
}


/*  To support fragmentation, the Network Layer (above) needs to know
    the maximum sized packet that it may present to the Data Link Layer.
    As the Netork Layer does not know the structure nor size of our Data
    Link Layer headers, it will ask us for this maximum size.
 */

int dll_maxsize(int link)
{
    return(linkinfo[link].transmitbufsize - DLL_FRAME_HEADER_SIZE);
}


/*  The function init_DLL() is called by the reboot_node() event-handler
    at the beginning of the simulation.  The function allocates an array of
    structures to manage each link's Data Link Layer state, and initializes
    each entry  (as this same code executes on all nodes, we do not know,
    until run-time, how many links we will need to manage).
    Two additional event-handlers are registered to receive frames from the
    Physical Layer, and to support retransmission of un-acknowledged frames.
 */

void init_DLL()
{
    int	l;

/*  ALLOCATE MEMORY AT RUN-TIME TO STORE EACH LINK'S STATE */
    links	= malloc((nodeinfo.nlinks+1) * sizeof(DLL_STATE));
    for(l=1 ; l<=nodeinfo.nlinks ; ++l) {
	links[l].ackexpected		= 0;
	links[l].nextframetosend	= 0;
	links[l].frameexpected		= 0;
	links[l].lasttimer		= NULLTIMER;
	links[l].lastlength		= 0;
	links[l].busy			= FALSE;
/*  INITIALIZE THE SMOOTHED ROUND-TRIP TIME TO 3*PROPAGATIONDEALY OF LINK */
	int64_I2L(links[l].srtt, 3);
	int64_MUL(links[l].srtt, links[l].srtt, linkinfo[l].propagationdelay);
    }

/*  REGISTER TWO EVENT-HANDLING FUNCTIONS */
    CHECK(CNET_set_handler(EV_PHYSICALREADY,    up_to_datalink, 0));
    CHECK(CNET_set_handler(EV_TIMER1,    	dll_timeouts,   0));
}
