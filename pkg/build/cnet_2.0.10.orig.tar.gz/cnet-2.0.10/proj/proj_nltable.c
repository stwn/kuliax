#include "proj.h"
#include "proj_nltable.h"

typedef struct {
    CnetAddr	destaddr;
    int		ackexpected;
    int		nextpackettosend;
    int		packetexpected;
} NL_SEQUENCETABLE;

static	NL_SEQUENCETABLE	*sequencetable;
static	int			sequencetable_size;


static NL_SEQUENCETABLE *find_sequence(CnetAddr destaddr)
{
    NL_SEQUENCETABLE	*tp;
    int			t;

    for(t=0, tp=sequencetable ; t<sequencetable_size ; ++t, ++tp)
	if(tp->destaddr == destaddr)
	    return(tp);

    sequencetable	= realloc((char *)sequencetable,
			    (sequencetable_size+1)*sizeof(NL_SEQUENCETABLE));

    tp				= &sequencetable[sequencetable_size];
    tp->destaddr		= destaddr;
    tp->ackexpected		= 0;
    tp->nextpackettosend	= 0;
    tp->packetexpected		= 0;
    ++sequencetable_size;
    return(tp);
}

int NL_nextpackettosend(CnetAddr destaddr) {
    return(find_sequence(destaddr)->nextpackettosend++);
}

int NL_ackexpected(CnetAddr destaddr) {
    return(find_sequence(destaddr)->ackexpected);
}

void NL_inc_ackexpected(CnetAddr destaddr) {
    find_sequence(destaddr)->ackexpected++;
}

int NL_packetexpected(CnetAddr destaddr) {
    return(find_sequence(destaddr)->packetexpected);
}

void NL_inc_packetexpected(CnetAddr destaddr) {
    find_sequence(destaddr)->packetexpected++;
}

/* ------------------------------------------------------------------- */

typedef struct {
    CnetAddr	destaddr;
    CnetInt64	time_lastused;

    int		minhops;
    int		minhop_link;
} NL_ROUTINGTABLE;


static	NL_ROUTINGTABLE	*routingtable;
static	int		routingtable_size;


static NL_ROUTINGTABLE *find_routing(CnetAddr destaddr)
{
    NL_ROUTINGTABLE	*tp;
    int			t;

    int			oldest		= 0;
    CnetInt64		oldest_time	= routingtable[0].time_lastused;

    for(t=0, tp=routingtable ; t<routingtable_size ; ++t, ++tp) {
	if(tp->destaddr == destaddr) {
	    tp->time_lastused	= nodeinfo.time_in_usec;
	    return(tp);
	}
	if(oldest_time > tp->time_lastused)
	    oldest	= t;
    }

    if(routingtable_size == MAXROUTES)
	tp			= &routingtable[oldest];
    else
	tp			= &routingtable[routingtable_size++];

    tp->destaddr		= destaddr;
    tp->time_lastused		= nodeinfo.time_in_usec;
    tp->minhops			= MAXHOPS;
    tp->minhop_link		= ALL_LINKS;
    return(tp);
}

int routing_maxhops(CnetAddr destaddr) {
    return(find_routing(destaddr)->minhops);
}

int routing_bestlink(CnetAddr destaddr) {
    int link	= find_routing(destaddr)->minhop_link;
    return(link == ALL_LINKS ? ALL_LINKS : (1 << link));
}

void routing_stats(CnetAddr destaddr, int hops, int link)
{
    NL_ROUTINGTABLE	*tp;

    tp = find_routing(destaddr);
    if(tp->minhops >= hops) {
	tp->minhops	= hops;
	tp->minhop_link	= link;
    }
}

static void show_routing(CnetEvent ev, CnetTimer timer, CnetData data)
{
    NL_ROUTINGTABLE	*tp;
    int			t;

    CNET_clear();
    printf("\n%14s %14s %14s\n", "destination","min-hops","minhop-link");
    for(t=0, tp=routingtable ; t<routingtable_size ; ++t, ++tp) {
	printf("%14d %14d", (int)tp->destaddr, tp->minhops);
	if(tp->minhop_link == ALL_LINKS)
	    printf(" %14s\n", "ALL-LINKS");
	else
	    printf(" %14d\n", tp->minhop_link);
    }
}

/* ------------------------------------------------------------------- */

void init_NL_tables()
{
    if(nodeinfo.nlinks > 31) {
	fprintf(stderr,"Too many links for this routing table to support\n");
	exit(1);
    }

    routingtable = (NL_ROUTINGTABLE *)malloc(MAXROUTES*sizeof(NL_ROUTINGTABLE));
    routingtable_size	= 0;

    sequencetable = (NL_SEQUENCETABLE *)malloc(sizeof(NL_SEQUENCETABLE));
    sequencetable_size	= 0;

    CHECK(CNET_set_handler(EV_DEBUG1, show_routing, 0));
    CHECK(CNET_set_debug_string( EV_DEBUG1, "NL routing"));
}
