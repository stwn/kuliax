
extern	void	nl_enqueue(int link, char *packet, int length);
extern	int	nl_dequeue(int link, char *packet, int *length);
extern	void	init_NL_queues(void);
