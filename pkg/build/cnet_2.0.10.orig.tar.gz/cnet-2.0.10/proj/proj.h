#include <cnet.h>
#include <stdlib.h>
#include <string.h>

/*  This file should contain declarations (only) of any functions and any
    global variables in the C source files that need to be visible to the
    other C files.  In particular, this header file should *not* provide
    any executable code (definitions) nor global variables (definitions).
 */

#define	FALSE		0
#define	TRUE		1
#define	UNKNOWN		(-1)


/* ----------------------------------------------------------------------- */

/*  Items provided by the Network Layer code (proj_nl.c) follow.
    We do not wish to 'expose' the implementation/format of the Network Layer
    packet to other layers, but we have a bit of a dilemma as the Data Link
    Layer needs to know the maximum size of each Network Layer packet so
    that they may be carried as the payload of each Data Link Layer frame.
    The best that we can do is provide the 'maximum ever' size of a packet,
    and ensure that the Network Layer code does not exceed this.
 */

#define	MAX_NL_PACKET_SIZE	(20*sizeof(int) + MAX_MESSAGE_SIZE)

extern	void init_NL(void);

extern	int  up_to_network(int link_arrived_on, char *packet, int length);
extern	int  down_from_network(int link_wanted, char *packet, int *length);


/* ----------------------------------------------------------------------- */

/*  Functions provided by the Data Link Layer code (proj_dll.c) follow:  */

extern	void init_DLL(void);

extern	int  down_to_datalink(int link_send_on, char *packet, int length);

extern	int  dll_maxsize(int link);
