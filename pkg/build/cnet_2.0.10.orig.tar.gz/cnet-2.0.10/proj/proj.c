#include "proj.h"

/*  The reboot_node() event handler of each node is called by the cnet
    scheduler to commence the whole simulation.  The event handler calls
    external functions to initialize the Data Link Layer and Network Layer,
    and then informs the Application Layer that it may now commence the
    generation of messages destined to all other nodes in the simulation.
 */

void reboot_node(CnetEvent ev, CnetTimer timer, CnetData data)
{
    init_DLL();
    init_NL();

    CNET_enable_application(ALLNODES);
}
