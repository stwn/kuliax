#include "proj.h"
#include "proj_nltable.h"
#include "proj_nlqueue.h"

/*  This file provides a simple Network Layer implementation which employs
    a simple routing algorithm based on flooding, end-to-end fragmentation
    and reassembly of large packets to 'squeeze' through small Data Link
    Layer conditions, and permits queries about the full route taken to
    visit, and return from, a nominated remote node.

    To simplify the implementation, query packets may not be fragmented.

    This Network Layer treats equally messages generated within the current
    node, messages being delivered for other nodes, route queries initiated
    at this node, other nodes' queries, and acknowledgments and replies for
    each of the above.  As the Data Link Layer (below) may only permit a
    single outstanding packet per link, this Network Layer queues packets,
    in a simple first-come-first-served manner before trying to 'push'
    them down to the Data Link Layer.
 */

typedef enum    	{ NL_DATA, NL_ACK, NL_QUERY, NL_REPLY } NL_PACKETKIND;

typedef struct {
    CnetAddr		src;
    CnetAddr		dest;
    NL_PACKETKIND	kind;      	/* only ever NL_DATA or NL_ACK */

    int			seqno;		/* 0, 1, 2, ... */
    int			hopsleft;	/* time to live, MAXHOPS...0 */
    int			hopstaken;

    int			total_length;	/* of all fragments in whole message */
    int			this_offset;	/* of this fragment in whole message */
    int			this_length;   	/* the length of the msg portion only */

    char		msg[MAX_MESSAGE_SIZE];
} NL_PACKET;

#define NL_PACKET_HEADER_SIZE		(sizeof(NL_PACKET) - MAX_MESSAGE_SIZE)
#define NL_PACKET_SIZE(p)		(NL_PACKET_HEADER_SIZE + p.this_length)
#define NL_PACKET_SIZE_POINTER(p)	(NL_PACKET_HEADER_SIZE + p->this_length)


/* ----------------------------------------------------------------------- */

/*  This Network Layer permits queries to be made about the full route
    taken to visit, and return from, a nominated remote node.  Query packets
    are managed as are any other (message) packets, with their payload
    carrying the intended destination and (growing) hop-by-hop route taken.
    All node names in the payload are represented as strings - simply printing
    out the payload thus prints out the route taken.

    To simplify the implementation, only one query may be outstanding at any
    one time.  This is managed by giving each query a unique sequence number,
    and only printing out the first returning route reply for the 'current'
    sequence number.  Query packets may not be fragmented.
 */

static struct {
    int		seqno;
    int		busy;
} query			= { 0, FALSE };


static void query_reset(CnetEvent ev, CnetTimer timer, CnetData data)
{
    ++query.seqno;
    query.busy	= FALSE;
    printf("\nwhere would you like to go today? ");
}


/* ----------------------------------------------------------------------- */


/*  Function reassemble_fragments() accepts a fragment (stored in a
whole packet), and attempts to locate all other fragments that have
been received from the same source node, with the same sequence number
(i.e. all fragments that are part of the same, original, message).
The function maintains a simple list of reassembly areas, and re-uses
these once all fragments of a particular message have arrived.

If this is the first fragment to have arrived from a particular message,
then space is allocated to hold the whole (yet to arrive) message.
Otherwise, the bytes of the fragment are saved, and a record is kept of
which bytes have arrived.
chrism.

 */

static int reassemble_fragments(NL_PACKET *fragment)
{
    typedef	struct _r {
	CnetData	src;
	int		seqno;
	int		total_length;
	char		*msg;
	char		*arrived;
	struct _r	*next;
    } REASSEMBLY;

    static	REASSEMBLY	*reassembly	= (REASSEMBLY *)NULL;

    REASSEMBLY	*this	= reassembly;
    int		byte;

    while(this) {
	if(this->total_length > 0 && 
	   this->src == fragment->src && this->seqno == fragment->seqno)
	    break;
	this	= this->next;
    }

    if(this == (REASSEMBLY *)NULL) {
	this	= reassembly;
	while(this) {
	    if(this->total_length == 0)
		break;
	    this	= this->next;
	}
	if(this == (REASSEMBLY *)NULL) {
	    this		= malloc(sizeof(REASSEMBLY));
	    this->next		= reassembly;
	    reassembly		= this;
	}

	this->src		= fragment->src;
	this->seqno		= fragment->seqno;
	this->total_length	= fragment->total_length;
	this->msg		= malloc(this->total_length);
	this->arrived		= malloc(this->total_length);
	memset(this->arrived, FALSE, this->total_length);
    }

    memcpy(&this->msg[fragment->this_offset],
	    fragment->msg, fragment->this_length);
    for(byte=0 ; byte<fragment->this_length ; ++byte)
	this->arrived[fragment->this_offset + byte]	= TRUE;

    for(byte=0 ; byte<this->total_length ; ++byte)
	if(this->arrived[byte] == FALSE)
	    return(FALSE);

    CHECK(CNET_write_application(this->msg, &this->total_length));

    free(this->msg);
    free(this->arrived);
    this->total_length	= 0;

    return(TRUE);
}

/*  Function fragment_and_enqueue() firstly emsures that it will be able
    'squeeze' through the requested link, buy asking the Data Link Layer
    how small each fragment must be.  The function next slices the packet
    into a number of each individual packets, with each fragment occupying
    a complete packet (i.e. a short payload will still be transmitted in a
    single packet representing a single fragment.  Each fragment (each with
    its own header) is then appended to the queue of outgoing packets for
    the requested link.
 */

static void fragment_and_enqueue(int link, NL_PACKET *packet)
{
    NL_PACKET	fragment;
    int		max_fragbody, left;
    char	*copy_from;

/*  ENSURE THAT EACH FRAGMENT'S HEADER+BODY  WILL BE ABLE TO BE SENT */
    max_fragbody = dll_maxsize(link) - NL_PACKET_HEADER_SIZE;
    if(max_fragbody <= 0) {
	fprintf(stderr,
		"Oops! %s cannot fragment a %d byte packet via link %d.\n",
		nodeinfo.nodename, NL_PACKET_SIZE_POINTER(packet), link);
	exit(1);
    }

/*  EACH FRAGMENT OF A LARGE MESSAGE HAS THE SAME HEADER, WITH ONLY THE
    PAYLOAD'S LENGTH AND FRAGMENT OFFSET CHANGING IN EACH FRAGMENT. */
    memcpy(&fragment, packet, NL_PACKET_HEADER_SIZE);
    copy_from	 = packet->msg;
    left	 = packet->this_length;
    do {
	fragment.this_length	= (left > max_fragbody) ? max_fragbody : left;
	memcpy(fragment.msg, copy_from, fragment.this_length);

/*  APPEND EACH FRAGMENT TO THE LINK'S OUTGOING QUEUE */
	nl_enqueue(link, (char *)&fragment, NL_PACKET_SIZE(fragment));

	fragment.this_offset	+= fragment.this_length;
	copy_from		+= fragment.this_length;
	left			-= fragment.this_length;
    } while(left > 0);
}


/* ----------------------------------------------------------------------- */

/*  The selective_flood() accepts a packet and a bitmap of links on which
    the packet should be transmitted (either just one link, or all links).
    The function is also informed if the packet should be fragmented -
    standard message packets and their acknowledgments are always fragmented,
    query packets and their replies are never fragmented.
    In either case, the packet will be enqueued for the requested links.
 */

static void selective_flood(int fragment, NL_PACKET *packet, int links_wanted)
{
    int	   link;

    for(link=1 ; link<=nodeinfo.nlinks ; ++link)
	if( links_wanted & (1<<link) ) {
	    if(fragment)
		fragment_and_enqueue(link, packet);
	    else
		nl_enqueue(link,(char *)packet,NL_PACKET_SIZE_POINTER(packet));
	}
}

/*  Event-handler down_to_network() is called when the Application Layer
    has a new message for delivery, or when a new route query is requested
    via the keybaord.  The event-type is used to determine what to do with
    the data to be transmitted.
 */

static void down_to_network(CnetEvent ev, CnetTimer timer, CnetData data)
{
    NL_PACKET	p;

/*  A NEW MESSAGE FOR DELIVERY TO A REMOTE HOST ... */
    if(ev == EV_APPLICATIONREADY) {
	p.this_length	= sizeof(p.msg);
	CHECK(CNET_read_application(&p.dest, p.msg, &p.this_length));
	CNET_disable_application(p.dest);

	p.kind		= NL_DATA;
	p.src		= nodeinfo.address;
	p.hopsleft	= routing_maxhops(p.dest);
	p.hopstaken	= 1;
	p.seqno		= NL_nextpackettosend(p.dest);

	p.total_length	= p.this_length;
	p.this_offset	= 0;

/*  FLOOD THE MESSAGE PACKET VIA THE BEST KNOWN LINK  - ALWAYS FRAGMENT */
	selective_flood(TRUE, &p, routing_bestlink(p.dest));
    }

/*  A ROUTE QUERY TO TRAVEL TO A REMOTE HSOT AND BACK */
    else if(ev == EV_KEYBOARDREADY) {
	char		destname[MAX_NODENAME_LEN];
	int		length;

	length		= sizeof(destname);
	CHECK(CNET_read_keyboard(destname, &length));

/*  ENSURE THAT WE HAVE MORE THAN JUST A BLANK LINE */
	if(length <= 1) {
	    query_reset(EV_DEBUG2,NULLTIMER,(CnetData)0);
	    return;
	}
/*  ONLY PERMIT ONE OUTSTANDING QUERY AT ONE TIME */
	if(query.busy) {
	    printf("sorry, busy undertaking another query\n");
	    return;
	}
	p.kind		= NL_QUERY;
	p.src		= nodeinfo.address;
	p.dest		= UNKNOWN;
	p.hopsleft	= MAXHOPS;
	p.hopstaken	= 1;
	p.seqno		= query.seqno;

/*  FORMAT THE INITIAL PAYLOAD WITH THE DESTINATION NAME AND OUR NAME */
	sprintf(p.msg, "%s %s", destname, nodeinfo.nodename);
	p.this_length	= strlen(p.msg)+1;	/* add 1 for NULL byte */
	p.total_length	= p.this_length;
	p.this_offset	= 0;

/*  FLOOD THE FORMATTED QUERY PACKET VIA ALL LINKS - DO NOT FRAGMENT */
	selective_flood(FALSE, &p, ALL_LINKS);
	query.busy	= TRUE;			/* busy until reply arrives */
    }
}


/*  As each route query and its reply pass through a node (including the
    remote destination, and the original source on return), the node's name
    (a string) is appended to the packet's payload.
 */

static void append_myname(NL_PACKET *p)
{
    strcat(p->msg, " -> ");
    strcat(p->msg, nodeinfo.nodename);
    p->this_length	= strlen(p->msg)+1;	/* add 1 for NULL byte */
    p->total_length	= p->this_length;
    p->this_offset	= 0;
}

/*  Function up_to_network() is called by the Data Link Layer (below) to
    'push' a newly arrived packet up to the Network Layer.  Packets arriving
    here are either sent to our Application Layer, display the routes taken
    by route queries, or are re-routed for other nodes.
 */

int up_to_network(int link_arrived_on, char *packet, int length)
{
    NL_PACKET	*p	= (NL_PACKET *)packet;

/*  A ROUTING QUERY STILL ON ITS WAY TO ITS DESTINATION */
    if(p->kind == NL_QUERY) {
	extern	int strncasecmp(const char *s1, const char *s2, size_t n);
	char	myname[MAX_NODENAME_LEN+1];

	if(p->src == nodeinfo.address)		/* stop unnecessary flooding */
	    return(0);

	append_myname(p);			/* record our name in payload */
	sprintf(myname, "%s ", nodeinfo.nodename);
/*  HAS THIS ROUTING QUERY BEEN SENT TO ME? */
	if(strncasecmp(p->msg, myname, strlen(myname)) == 0) {
	    p->kind		= NL_REPLY;
	    p->dest		= p->src;
	    p->src		= nodeinfo.address;
	    p->hopsleft		= MAXHOPS;

	    selective_flood(FALSE, p, routing_bestlink(p->dest));
	}
	else if(--p->hopsleft > 0)		/* send it back out again */
	    selective_flood(FALSE, p, ALL_LINKS & ~(1<<link_arrived_on));
    }

/*  A ROUTING REPLY - IF REQUESTED BY ME, PRINT THE ACTUAL ROUTE TAKEN */
    else if(p->kind == NL_REPLY) {
	append_myname(p);			/* record our name in payload */
	if(p->dest == nodeinfo.address) {
	    if(p->seqno == query.seqno) {
		char	*s	= p->msg;

		while(*s && *s != ' ')
		    ++s;
		printf("%s\n", s);		/* print route taken */
		query_reset(EV_DEBUG2,NULLTIMER,(CnetData)0);
	    }
	}
	else if(--p->hopsleft > 0)		/* send it back out again */
	    selective_flood(FALSE, p, routing_bestlink(p->dest));
    }

/*  IF NOT A ROUTING PACKET, IT MUST BE A DATA PACKET OR ITS ACKNOWLEDGMENT */ 
    else if(p->dest == nodeinfo.address) {	/*  THIS PACKET IS FOR ME */
	if(p->kind == NL_DATA && p->seqno == NL_packetexpected(p->src)) {

/*  ADD THIS FRAGMENT TO OTHERS FROM THE SAME SOURCE, UNTIL ALL HAVE ARRIVED */
	    if(reassemble_fragments(p) == TRUE) { /* all fragments arrived? */
		CnetAddr	save;

		NL_inc_packetexpected(p->src);
		routing_stats(p->src, p->hopstaken, link_arrived_on);

		save	 	= p->src;	/* NL_DATA becomes NL_ACK */
		p->src	 	= p->dest;
		p->dest	 	= save;

		p->kind	 	= NL_ACK;
		p->hopsleft	= routing_maxhops(p->dest);
		p->hopstaken	= 1;
		p->this_length	= 0;
		p->total_length	= p->this_length;
		p->this_offset	= 0;
		selective_flood(TRUE, p, routing_bestlink(p->dest) );
	    }
	}
/*  ONE OF MY MESSAGES HAS BEEN ACKNOWLEDGED, PERMIT THE NEXT MESSAGE */
	else if(p->kind == NL_ACK && p->seqno == NL_ackexpected(p->src)) {
	    routing_stats(p->src, p->hopstaken, link_arrived_on);
	    NL_inc_ackexpected(p->src);
	    CNET_enable_application(p->src);
	}
    }

/* OTHERWISE, FINALLY, THIS PACKET IS FOR ANOTHER NODE */
    else {
	if(--p->hopsleft > 0) {		/* send it back out again */
	    p->hopstaken++;
	    routing_stats(p->src, p->hopstaken, link_arrived_on);
	    selective_flood(TRUE, p,
			    routing_bestlink(p->dest) & ~(1<<link_arrived_on));
	}
    }
    return(0);
}


/*  Function down_from_network() is called from the Data Link Layer to
    'pull' down the next packet/fragment for transmitting.
    As all packets are placed on outgoing queues (one per link), this
    function simply attempts to remove the next packet from the requested
    queue.  If there is a packet waiting on the queue, down_from_network()
    returns TRUE, othersise the Data Link Layer will have to wait until our
    Network Layer actually has something for it.
 */

int down_from_network(int link_wanted, char *packet, int *length)
{
    return(nl_dequeue(link_wanted, packet, length));
}


/*  Called from reboot_node() to initialize the Network Layer */
void init_NL()
{
    init_NL_tables();
    init_NL_queues();

    CHECK(CNET_set_handler(EV_APPLICATIONREADY, down_to_network, 0));
    CHECK(CNET_set_handler(EV_KEYBOARDREADY,    down_to_network, 0));

    CHECK(CNET_set_handler(EV_DEBUG2, query_reset, 0));
    CHECK(CNET_set_debug_string( EV_DEBUG2, "reset query"));

    query_reset(EV_DEBUG2,NULLTIMER,(CnetData)0);
}
