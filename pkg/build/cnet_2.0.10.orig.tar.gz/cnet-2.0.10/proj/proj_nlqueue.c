#include "proj.h"

#define	NEW(type)	(type *)malloc(sizeof(type))
#define	FREE(obj)	free(obj)


/*  This is the definition of each ELEMENT in the queue. The 'next' field
    is naturally required, but any other fields may be used to hold the
    data of each element.
 */

typedef struct _e {
    char	*data;
    int		length;
    struct _e	*next;
} ELEMENT;

/*  Next we define the QUEUE itself, as a pointer to the head of the the
    queue (the pointer *head), a pointer to the tail of the queue (the *tail).
 */

typedef struct {
    ELEMENT	*head;
    ELEMENT	*tail;
} QUEUE;

static	QUEUE	*queues;


/* -------------------------------------------------------------------- */

void nl_enqueue(int link, char *packet, int length)
{
    ELEMENT		*newe;

    newe		= NEW(ELEMENT);		/* allocate space for element */
    newe->data		= malloc(length);	/* copy element's data field */
    memcpy(newe->data, packet, length);
    newe->length	= length;
    newe->next		= (ELEMENT *)NULL;	/* nothing follows this */

    if(queues[link].head == (ELEMENT *)NULL) {	/* is the queue empty? */
	queues[link].head	= newe;
	queues[link].tail	= newe;
    }
    else {					/* no, just append to tail */
	queues[link].tail->next	= newe;
	queues[link].tail	= newe;
    }

    if(down_to_datalink(link,
			queues[link].head->data, queues[link].head->length)) {

	ELEMENT	*olde	= queues[link].head;	/* remember old element */

	queues[link].head	= queues[link].head->next;
	if(queues[link].tail == olde) {	/* only one item on queue? */
	    queues[link].head	= (ELEMENT *)NULL;
	    queues[link].tail	= (ELEMENT *)NULL;
	}
	FREE(olde->data);		/* deallocate storage of data */
	FREE(olde);			/* deallocate storage of element */
    }
}


int nl_dequeue(int link, char *packet, int *length)
{
    ELEMENT	*olde;

    if(queues[link].head == (ELEMENT *)NULL)
	return(FALSE);

    olde	= queues[link].head;	/* remember old element */

    queues[link].head		= queues[link].head->next;
    if(queues[link].tail == olde) {	/* only one item on queue? */
	queues[link].head	= (ELEMENT *)NULL;
	queues[link].tail	= (ELEMENT *)NULL;
    }

    memcpy(packet, olde->data, olde->length);
    *length	= olde->length;

    FREE(olde->data);			/* deallocate storage of data */
    FREE(olde);				/* deallocate storage of element */
    return(TRUE);
}


/* -------------------------------------------------------------------- */

void init_NL_queues()
{
    int	q;

    queues	= malloc((nodeinfo.nlinks+1) * sizeof(QUEUE));
    for(q=1 ; q<=nodeinfo.nlinks ; ++q) {
	queues[q].head	= (ELEMENT *)NULL;
	queues[q].tail	= (ELEMENT *)NULL;
    }
}
