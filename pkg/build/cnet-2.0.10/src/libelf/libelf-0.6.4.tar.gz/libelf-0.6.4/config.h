/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define if you have a working `mmap' system call.  */
#define HAVE_MMAP 1

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef off_t */

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you want to include extra debugging code */
/* #undef ENABLE_DEBUG */

/* Define if memmove() does not copy overlapping arrays correctly */
/* #undef HAVE_BROKEN_MEMMOVE */

/* Define if you have the catgets function. */
#define HAVE_CATGETS 1

/* Define if you have the gettext function. */
/* #undef HAVE_GETTEXT */

/* Define if you have the memset function.  */
#define HAVE_MEMSET 1

/* Define if struct nlist is declared in <elf.h> or <sys/elf.h> */
#define HAVE_STRUCT_NLIST_DECLARATION 1

/* Define if Elf32_Dyn is declared in <link.h> */
/* #undef NEED_LINK_H */

/* Define if you have the ftruncate function.  */
#define HAVE_FTRUNCATE 1

/* Define if you have the getpagesize function.  */
#define HAVE_GETPAGESIZE 1

/* Define if you have the memcmp function.  */
#define HAVE_MEMCMP 1

/* Define if you have the memcpy function.  */
#define HAVE_MEMCPY 1

/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1

/* Define if you have the valloc function.  */
#define HAVE_VALLOC 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1
